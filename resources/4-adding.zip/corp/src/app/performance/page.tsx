export default function PerformancePage() {
  return <div>Performance Page!</div>;
}

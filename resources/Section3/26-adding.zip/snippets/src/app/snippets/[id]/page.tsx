export default function SnippetShowPage(props: any) {
  console.log(props);
  return <div>Show a snippet</div>;
}

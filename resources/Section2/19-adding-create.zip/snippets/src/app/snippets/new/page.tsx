export default function SnippetCreatePage() {
  return <div>Create a Snippet!</div>;
}

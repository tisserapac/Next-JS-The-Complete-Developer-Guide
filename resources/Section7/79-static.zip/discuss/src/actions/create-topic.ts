'use server';

export async function createTopic() {
  // TODO: revalidate the homepage
}

'use server';

export async function createPost() {
  // TODO: revalidate the topic show page
}

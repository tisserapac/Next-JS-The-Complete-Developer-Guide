export default function TopicShowPage() {
  return <div>Topic Show</div>;
}

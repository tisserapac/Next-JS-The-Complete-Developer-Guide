'use server';

export async function createComment() {
  // TODO: revalidate post show page
}

export default function TopicCreateForm() {
  return <div>Topic Create Form</div>;
}
